document.addEventListener('DOMContentLoaded', function() {
    const contactForm = document.getElementById('contactForm');
    const thankYouMsg = document.getElementById('thankYouMsg');

    contactForm.addEventListener('submit', function(event) {
        event.preventDefault();
        // Simulate form submission
        setTimeout(function() {
            // Hide the contact form
            contactForm.style.display = 'none';
            // Show the thank you message
            thankYouMsg.style.display = 'block';
        }, 1000); // Change the delay time as needed
    });
});
